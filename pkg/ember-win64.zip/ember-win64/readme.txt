Ember
=====

A secret society is planning a top-secret operation called "Ember". For this
operation, they need a nuclear bomb. The goal of operation Ember is unknown to
you. All you know is that their operation isn't ready to enter it's final phase
yet.

Some other group has found out about operation Ember and is trying to stop it.
You have been hired to protect the bomb. You don't know if you're helping the
good or the evil, all you know is that that bomb must stay safe.


Ember is a game made by Darkwater using LÖVE (http://love2d.org) for the 28th
Ludum Dare, following the theme "You Only Get One".

For more information, o tohttp://novaember.com/ld/
